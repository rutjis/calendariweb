export interface Booking {
  id: string
  name: string
  email: string
  date: string
  time: string
}

