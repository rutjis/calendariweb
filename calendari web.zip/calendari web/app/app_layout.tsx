import { initDatabase } from './db/init'

// Initialize database tables
initDatabase()

